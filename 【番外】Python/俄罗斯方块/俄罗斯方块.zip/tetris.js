let canvas = document.getElementById('gameCanvas');
let ctx = canvas.getContext('2d');
let currentBlock = {
    x: 4,
    y: 0,
    shape: [],
    color: ''
};

let gameGrid = [];
let gameSpeed = 500; // 下落速度，单位为毫秒
let gameInterval;
let score = 0;
let isPaused = false;

// 定义方块形状和颜色
const shapes = [
    { shape: [[1, 1], [1, 1]], color: '#007bff' }, // 方块
    { shape: [[1, 1, 1, 1]], color: '#28a745' }, // 直线
    { shape: [[1, 1, 1], [0, 1, 0]], color: '#dc3545' }, // T形
    { shape: [[1, 1, 0], [0, 1, 1]], color: '#ffc107' }, // Z形
    { shape: [[0, 1, 1], [1, 1, 0]], color: '#6c757d' }, // S形
    { shape: [[1, 1, 1], [1, 0, 0]], color: '#17a2b8' }, // L形
    { shape: [[1, 1, 1], [0, 0, 1]], color: '#fd7e14' } // J形
];

// 初始化游戏网格
function initGameGrid() {
    for (let y = 0; y < 24; y++) {
        gameGrid[y] = [];
        for (let x = 0; x < 12; x++) {
            gameGrid[y][x] = 0;
        }
    }
}

// 绘制游戏网格
function drawGameGrid() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    for (let y = 0; y < 24; y++) {
        for (let x = 0; x < 12; x++) {
            if (gameGrid[y][x]) {
                ctx.fillStyle = gameGrid[y][x];
                ctx.fillRect(x * 20, y * 20, 20, 20);
                ctx.strokeStyle = 'rgba(0, 0, 0, 0.1)';
                ctx.strokeRect(x * 20, y * 20, 20, 20);
            }
        }
    }
}

// 绘制方块
function drawBlock() {
    ctx.fillStyle = currentBlock.color;
    currentBlock.shape.forEach((row, y) => {
        row.forEach((value, x) => {
            if (value) {
                ctx.fillRect((currentBlock.x + x) * 20, (currentBlock.y + y) * 20, 20, 20);
                ctx.strokeStyle = 'rgba(0, 0, 0, 0.1)';
                ctx.strokeRect((currentBlock.x + x) * 20, (currentBlock.y + y) * 20, 20, 20);
            }
        });
    });
}

// 检查方块是否可以移动到指定位置
function canMove(x, y, shape) {
    for (let row = 0; row < shape.length; row++) {
        for (let col = 0; col < shape[row].length; col++) {
            if (shape[row][col]) {
                let newX = currentBlock.x + x + col;
                let newY = currentBlock.y + y + row;
                if (newX < 0 || newX >= 12 || newY >= 24 || (newY >= 0 && gameGrid[newY][newX])) {
                    return false;
                }
            }
        }
    }
    return true;
}

// 旋转方块
function rotateBlock() {
    let newShape = currentBlock.shape[0].map((val, index) => 
        currentBlock.shape.map(row => row[index]).reverse()
    );
    if (canMove(0, 0, newShape)) {
        currentBlock.shape = newShape;
        drawGameGrid();
        drawBlock();
    }
}

// 移动方块
function moveBlock(dx, dy) {
    if (canMove(dx, dy, currentBlock.shape)) {
        currentBlock.x += dx;
        currentBlock.y += dy;
        drawGameGrid();
        drawBlock();
    }
}

// 消除满行
function clearLines() {
    let linesCleared = 0;
    for (let y = 23; y >= 0; y--) {
        let isFull = true;
        for (let x = 0; x < 12; x++) {
            if (gameGrid[y][x] === 0) {
                isFull = false;
                break;
            }
        }
        if (isFull) {
            gameGrid.splice(y, 1);
            gameGrid.unshift(new Array(12).fill(0));
            y++;
            linesCleared++;
            drawGameGrid();
        }
    }
    if (linesCleared > 0) {
        score += linesCleared * 100;
        document.getElementById('score').innerText = `得分: ${score}`;
    }
}

// 检查游戏是否结束
function checkGameOver() {
    for (let x = 0; x < 12; x++) {
        if (gameGrid[0][x]) {
            clearInterval(gameInterval);
            alert('游戏结束');
            return true;
        }
    }
    return false;
}

// 下落方块
function dropBlock() {
    if (canMove(0, 1, currentBlock.shape)) {
        currentBlock.y += 1;
        drawGameGrid();
        drawBlock();
    } else {
        // 将方块固定到游戏网格
        currentBlock.shape.forEach((row, y) => {
            row.forEach((value, x) => {
                if (value) {
                    gameGrid[currentBlock.y + y][currentBlock.x + x] = currentBlock.color;
                }
            });
        });
        // 消除满行
        clearLines();
        // 检查游戏是否结束
        if (checkGameOver()) return;
        // 生成新方块
        generateNewBlock();
    }
}

// 生成新方块
function generateNewBlock() {
    let randomShape = shapes[Math.floor(Math.random() * shapes.length)];
    currentBlock.x = 4;
    currentBlock.y = 0;
    currentBlock.shape = randomShape.shape;
    currentBlock.color = randomShape.color;
    drawGameGrid();
    drawBlock();
}

// 开始游戏
function startGame() {
    initGameGrid();
    drawGameGrid();
    generateNewBlock(); // 生成第一个方块
    gameInterval = setInterval(dropBlock, gameSpeed);
}

// 暂停游戏
function pauseGame() {
    if (isPaused) {
        gameInterval = setInterval(dropBlock, gameSpeed);
        document.getElementById('pauseButton').innerText = '暂停';
    } else {
        clearInterval(gameInterval);
        document.getElementById('pauseButton').innerText = '继续';
    }
    isPaused = !isPaused;
}

// 重新开始游戏
function restartGame() {
    clearInterval(gameInterval);
    score = 0;
    document.getElementById('score').innerText = `得分: ${score}`;
    startGame();
}

// 初始绘制
startGame();

// 绑定旋转按钮事件
document.getElementById('rotateButton').addEventListener('click', rotateBlock);

// 绑定暂停按钮事件
document.getElementById('pauseButton').addEventListener('click', pauseGame);

// 绑定重新开始按钮事件
document.getElementById('restartButton').addEventListener('click', restartGame);

// 绑定键盘事件
document.addEventListener('keydown', (event) => {
    switch (event.key) {
        case 'ArrowLeft':
            moveBlock(-1, 0);
            break;
        case 'ArrowRight':
            moveBlock(1, 0);
            break;
        case 'ArrowDown':
            moveBlock(0, 1);
            break;
        case 'ArrowUp':
            rotateBlock();
            break;
        case ' ': // 空格键暂停/继续
            pauseGame();
            break;
    }
});
